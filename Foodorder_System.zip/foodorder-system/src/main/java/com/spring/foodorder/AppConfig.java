package com.spring.foodorder;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class AppConfig {

    @Bean
    public Customer customer() {
        return new Customer("Kamakshi", "9177488507", "Indian");
    }

    @Bean
    public Restaurant restaurant() {
        return new Restaurant("Hyderabadi Handi Biriyani", "Bangalore", new String[]{"Indian", "Chinese"});
    }

    @Bean
    public FoodOrderService foodOrderService() {
        return new FoodOrderService(customer(), restaurant());
    }
}